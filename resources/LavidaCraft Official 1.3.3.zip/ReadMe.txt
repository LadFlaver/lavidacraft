Website: lavidacraft.42web.io

Please use this pack as follows:
When redistributing the pack keep the unedited ReadMe.txt in the pack
Feel free to reverse engineer it. I know I reverse engineered texture packs to learn how to make this in the first place.
Feel free to edit the contents of this pack. If you don't like a texture feel free to delete or make changes to it.

To use:
Launch Minecraft,
Navigate to the "Options" Menu,
Select "Resource Packs",
Click "Open Pack Folder",
Move texture pack into the folder (zip or folder, shouldn't matter),
In minecraft hit the button to use the pack,
Click "Done",
After loading the pack should work.