Pack made by Lad_Flaver. Copyright 2024. All Rights Reserved.

NOT AN OFFICIAL MINECRAFT PRODUCT. NOT  ASSOCIATED WITH MOJANG OR MICROSOFT.

Website: https://ladflaver.github.io/lavidacraft

Please do not redistribute this resource pack!

Please also check out Vanilla Tweaks! Website: https://vanillatweaks.net/picker/resource-packs/
LavidaCraft is not affiliated with Vanilla Tweaks. I just like it.

This pack is not intended to be a retexture of the game, but add improvements and tweaks to various parts of the game.

OptiFine Features:
If you would like to disable the custom loading screen delete or rename the color.properties file.
If you would like to disable emissive textures delete or rename the emissive.properties file.