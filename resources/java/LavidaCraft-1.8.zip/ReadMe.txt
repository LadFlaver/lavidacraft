Pack made by Lad_Flaver. Copyright 2024. All Rights Reserved.

Do not redistribute this resource pack!

NOT AN OFFICIAL MINECRAFT PRODUCT. NOT ASSOCIATED WITH MOJANG OR MICROSOFT.

Website: https://ladflaver.github.io/lavidacraft

Other projects by me: https://modrinth.com/user/Lad_Flaver

This pack is not intended to be a retexture of the game, but adds improvements and tweaks to various parts of the game.

OptiFine Features:
If you would like to disable the custom loading screen delete or rename the color.properties file.
If you would like to disable emissive textures delete or rename the emissive.properties file.