Pack made by Lad_Flaver. Copyright 2025. All Rights Reserved.

Do not redistribute this resource pack!

NOT AN OFFICIAL MINECRAFT PRODUCT. NOT ASSOCIATED WITH MOJANG OR MICROSOFT.

Website: https://ladflaver.github.io/lavidacraft

Other projects by me: https://modrinth.com/user/Lad_Flaver